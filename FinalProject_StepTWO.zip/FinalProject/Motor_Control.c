#include <MKL25Z4.H>
#include "user_defs.h"
#include "LEDs.h"
#include "motors.h"

void Init_MOTORs(void) {
	// Enable clock to ports B and D
	SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTD_MASK;;
	
	// Make 3 pins GPIO
	PORTB->PCR[OPEN_MOTOR_POS] &= ~PORT_PCR_MUX_MASK;          
	PORTB->PCR[OPEN_MOTOR_POS] |= PORT_PCR_MUX(1);          
	PORTB->PCR[CLOSE_MOTOR_POS] &= ~PORT_PCR_MUX_MASK;          
	PORTB->PCR[CLOSE_MOTOR_POS] |= PORT_PCR_MUX(1);   
	
	// Set ports to outputs
	PTB->PDDR |= MASK(OPEN_MOTOR_POS) | MASK(CLOSE_MOTOR_POS);
}

void Control_MOTORs(unsigned int open_on, unsigned int close_on) {
	if (open_on) {
			PTB->PCOR = MASK(OPEN_MOTOR_POS);
	} else {
			PTB->PSOR = MASK(OPEN_MOTOR_POS); 
	}
	if (close_on) {
			PTB->PCOR = MASK(CLOSE_MOTOR_POS);
	}	else {
			PTB->PSOR = MASK(CLOSE_MOTOR_POS); 
	} 
}	
