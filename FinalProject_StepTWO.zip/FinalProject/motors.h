#ifndef MOTORS_H
#define MOTORS_H

// Freedom KL25Z LEDs
#define OPEN_MOTOR_POS (2)		// on port B
#define CLOSE_MOTOR_POS (3) 	// on port B
#define Motor_DELAY (500000)  //before motor shuts off

// function prototypes
void Init_MOTORs(void);
void Control_MOTORs(unsigned int open_on, unsigned int close_on);


#endif
